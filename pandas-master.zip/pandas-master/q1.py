import pandas as pd
import numpy as np
data = {'Name':['nikhil','xyz'], 'Age':[21,22], 'mail':['nikhlbaliyan113@gmail.com','xyz@gmail.com'],'phone':[7300704200,9874561230]}
df = pd.DataFrame(data)
print(df)